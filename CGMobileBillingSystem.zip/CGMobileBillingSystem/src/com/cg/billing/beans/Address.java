package com.cg.billing.beans;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;

@Embeddable
public class Address {
	
	private String city, state;
	private int pinCode;
	
	@ManyToOne
	private Customer customer;
	public Address() {}
	public Address(String city, String state, int pinCode, Customer customer) {
		super();
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.customer = customer;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", pinCode=" + pinCode + ", customer=" + customer + "]";
	}
	
	

}