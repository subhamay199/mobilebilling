package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.Address;
import com.cg.billing.beans.Bill;

public interface AddressDAO {
	Address save(Address address);
	boolean update(Address address);
	Address findOne(int pinCode);
	List<Address>findAll();
}
