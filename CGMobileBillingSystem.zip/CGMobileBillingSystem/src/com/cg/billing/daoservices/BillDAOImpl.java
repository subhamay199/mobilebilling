package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.Bill;

public class BillDAOImpl implements BillDAO {

	@Override
	public Bill save(Bill bill) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Bill bill) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Bill findOne(int billId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bill> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
