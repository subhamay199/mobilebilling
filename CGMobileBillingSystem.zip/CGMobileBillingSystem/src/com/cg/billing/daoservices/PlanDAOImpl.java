package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.Plan;

public class PlanDAOImpl implements PlanDAO {

	@Override
	public Plan save(Plan plan) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(Plan plan) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Plan findOne(int planId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Plan> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
